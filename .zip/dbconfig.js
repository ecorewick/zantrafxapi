const config={
    user:"DB_ZantraFx",
    password:"DB_Z@ntr@Fx41",
    server:"161.97.111.182",
    database:"DB_ZantraFx",
    options: {
        encrypt:false,
        useUTC:true,
    },
    port : 1433,
};

module.exports= config